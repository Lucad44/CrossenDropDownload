#!/usr/bin/env bash
# CrossenDrop installer for Fedora Linux (GNOME/Wayland). Installs per user, no root needed except for dnf.
#
#   ./install.sh                  # full install (dnf deps, venv, launcher, systemd --user scheduler)
#   ./install.sh --with-ollama    # also install Ollama and pull the suggested models
#   ./install.sh --no-system-deps # skip dnf (e.g. inside a toolbox/container or when deps are present)
#   ./install.sh --no-service     # do not enable the background scheduler
#   ./install.sh --uninstall      # remove the app (keeps your data in ~/.local/share/crossendrop/data)
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${CROSSENDROP_PREFIX:-$HOME/.local/share/crossendrop}"
VENV="$PREFIX/venv"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"
UNIT_DIR="$HOME/.config/systemd/user"
SYSTEM_DEPS=1; SERVICE=1; OLLAMA=0; UNINSTALL=0

for arg in "$@"; do
  case "$arg" in
    --no-system-deps) SYSTEM_DEPS=0 ;;
    --no-service) SERVICE=0 ;;
    --with-ollama) OLLAMA=1 ;;
    --uninstall) UNINSTALL=1 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

say() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWARN:\033[0m %s\n' "$*" >&2; }
have() { command -v "$1" >/dev/null 2>&1; }
user_systemd() { have systemctl && systemctl --user show-environment >/dev/null 2>&1; }

if [[ $UNINSTALL -eq 1 ]]; then
  say "Removing CrossenDrop (your data stays in $PREFIX/data and ~/.config/crossendrop)"
  if user_systemd; then systemctl --user disable --now crossendrop-scheduler.service 2>/dev/null || true; fi
  rm -f "$UNIT_DIR/crossendrop-scheduler.service" "$BIN_DIR/crossendrop" "$BIN_DIR/dropforge" \
        "$APPS_DIR/crossendrop.desktop" "$ICON_DIR/crossendrop.svg"
  rm -rf "$VENV"
  have update-desktop-database && update-desktop-database "$APPS_DIR" >/dev/null 2>&1 || true
  say "Done."
  exit 0
fi

if [[ -r /etc/os-release ]]; then . /etc/os-release; fi
if [[ "${ID:-}" != "fedora" ]]; then
  warn "This installer targets Fedora; detected '${ID:-unknown}'. Continuing, but install system packages yourself."
  [[ $SYSTEM_DEPS -eq 1 ]] && ! have dnf && SYSTEM_DEPS=0
fi

if [[ $SYSTEM_DEPS -eq 1 ]]; then
  say "Installing system packages with dnf (sudo)"
  PKGS=(python3 python3-pip python3-gobject gtk3 webkit2gtk4.1 libsecret gnome-keyring libnotify sqlite
        cairo-gobject gobject-introspection)
  sudo dnf install -y "${PKGS[@]}"
  [[ $OLLAMA -eq 1 ]] && { sudo dnf install -y ollama || warn "Ollama not in your repos; see https://ollama.com/download"; }
fi

PY="$(command -v python3 || true)"
[[ -n "$PY" ]] || { echo "python3 not found" >&2; exit 1; }
"$PY" - <<'PYCHK' || { echo "CrossenDrop needs Python 3.12 or newer" >&2; exit 1; }
import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)
PYCHK

# A release download carries the app ready-built, one package per Python version (wheels/); a source checkout
# (the git branch) is installed from its sources.
PKG="$SRC"
if [[ -d "$SRC/wheels" ]]; then
  PYTAG="$("$PY" -c 'import sys; print("cp%d%d" % sys.version_info[:2])')"
  PKG="$(find "$SRC/wheels" -maxdepth 1 -name "crossendrop-*-$PYTAG-none-any.whl" | head -n 1)"
  if [[ -z "$PKG" ]]; then
    echo "This CrossenDrop download supports Python 3.12, 3.13 and 3.14; this computer's python3 is" \
         "$("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])'). Download the newest CrossenDrop." >&2
    exit 1
  fi
fi

say "Creating virtual environment in $VENV"
mkdir -p "$PREFIX"
# --system-site-packages lets pywebview use PyGObject/WebKitGTK from Fedora's packages.
"$PY" -m venv --system-site-packages "$VENV"
"$VENV/bin/python" -m pip install -q --upgrade pip
EXTRAS="[gui]"
"$VENV/bin/python" -c "import gi" 2>/dev/null || { warn "PyGObject not available: the app will open in your browser instead of a native window."; EXTRAS=""; }
"$VENV/bin/python" -m pip install -q "$PKG$EXTRAS" || "$VENV/bin/python" -m pip install -q "$PKG"
# Fedora's python3-pillow (visible through --system-site-packages) may lack WebP/AVIF; the wheel bundles them.
"$VENV/bin/python" -m pip install -q --upgrade --ignore-installed pillow || warn "Could not upgrade Pillow; some product pictures may not be readable."

if [[ ! -d "$SRC/wheels" && ! -f "$SRC/src/crossendrop/web/static/index.html" ]]; then
  if have npm; then
    say "Building the GUI"
    (cd "$SRC/frontend" && npm ci --no-audit --no-fund && npm run build)
    "$VENV/bin/python" -m pip install -q --force-reinstall --no-deps "$SRC"
  else
    warn "GUI assets missing and npm not found; install nodejs and re-run, or use the CLI/MCP."
  fi
fi

say "Linking commands into $BIN_DIR"
mkdir -p "$BIN_DIR"
ln -sf "$VENV/bin/crossendrop" "$BIN_DIR/crossendrop"
ln -sf "$VENV/bin/crossendrop" "$BIN_DIR/dropforge"
case ":$PATH:" in *":$BIN_DIR:"*) ;; *) warn "$BIN_DIR is not on your PATH; add it to ~/.bashrc." ;; esac

# dev = the developer's build (starts in mock mode); prod = the build distributed to customers (src/crossendrop/edition.py)
EDITION="$("$VENV/bin/python" -c 'from crossendrop.edition import EDITION; print(EDITION)')"
if [[ "$EDITION" == "prod" ]]; then
  say "Initialising data folders and database (existing settings and data are kept)"
else
  say "Initialising data folders and database (a new install starts in mock mode; existing settings are kept)"
fi
"$VENV/bin/crossendrop" init --json >/dev/null

say "Installing desktop launcher and icon"
mkdir -p "$APPS_DIR" "$ICON_DIR"
install -m 644 "$SRC/packaging/crossendrop.svg" "$ICON_DIR/crossendrop.svg"
sed "s#^Exec=.*#Exec=$VENV/bin/crossendrop gui#" "$SRC/packaging/crossendrop.desktop" > "$APPS_DIR/crossendrop.desktop"
chmod 644 "$APPS_DIR/crossendrop.desktop"
have update-desktop-database && update-desktop-database "$APPS_DIR" >/dev/null 2>&1 || true
have gtk-update-icon-cache && gtk-update-icon-cache -q "$HOME/.local/share/icons/hicolor" 2>/dev/null || true

say "Installing the background scheduler (systemd --user)"
mkdir -p "$UNIT_DIR"
sed "s#^ExecStart=.*#ExecStart=$VENV/bin/crossendrop scheduler#" \
  "$SRC/packaging/systemd/crossendrop-scheduler.service" > "$UNIT_DIR/crossendrop-scheduler.service"
if [[ $SERVICE -eq 1 ]] && user_systemd; then
  systemctl --user daemon-reload
  systemctl --user enable crossendrop-scheduler.service
  # restart (not just start): a scheduler from before this install would keep running the old code
  systemctl --user restart crossendrop-scheduler.service
else
  warn "systemd --user not available or --no-service given; start later with: systemctl --user enable --now crossendrop-scheduler"
fi

if [[ $OLLAMA -eq 1 ]] && have ollama; then
  say "Pulling suggested Ollama models (this can take a while)"
  read -r TEXT VISION < <("$VENV/bin/python" -c "from crossendrop.ai.hardware import suggest_models as s; m=s(); print(m['text_model'], m['vision_model'])")
  (user_systemd && systemctl --user start ollama 2>/dev/null) || (pgrep -x ollama >/dev/null || (ollama serve >/dev/null 2>&1 &))
  sleep 2
  ollama pull "$TEXT" && ollama pull "$VISION" || warn "Model pull failed; pull them later in Settings → AI."
fi

say "Checking health"
"$VENV/bin/crossendrop" health || true
if [[ "$EDITION" == "prod" ]]; then
cat <<MSG

CrossenDrop is installed.
  • Start it from the GNOME app grid ("CrossenDrop") or run:  crossendrop gui
  • The first start walks you through the set-up: your business details, where you sell, your CrossenDrop
    license key (from your purchase e-mail), your eBay seller account and your AliExpress account.
  • Optional – let Claude help with daily operations:  claude mcp add crossendrop -- $VENV/bin/crossendrop mcp
MSG
else
cat <<MSG

CrossenDrop (developer build) is installed.
  • Start it from the GNOME app grid ("CrossenDrop") or run:  crossendrop gui
  • It starts in MOCK mode (no keys needed). Follow the setup wizard, then docs/GO_LIVE_CHECKLIST.md.
  • Claude Code:  claude mcp add crossendrop -- $VENV/bin/crossendrop mcp
MSG
fi
