CrossenDrop 1.0.1 for macOS
=========================

Install
-------
1. Open Terminal (Applications > Utilities > Terminal).
2. Type  cd  and a space, drag this folder into the Terminal window, press Return.
3. Run:   bash install.sh
   (add --with-ollama to also install the local AI)

No administrator password is needed. CrossenDrop appears in Launchpad and in your Applications folder
(~/Applications), and a background service keeps your listings and orders up to date.

You need macOS 12 or newer and Python 3.12, 3.13 or 3.14 – if your Mac has none, the installer installs it with
Homebrew, or tells you to get it from python.org. You also need your CrossenDrop license key, an eBay seller
account and the normal AliExpress account you shop with.

The first time, macOS may ask whether "python" may use your keychain: choose Always Allow.

Update:     download the new version and run  bash install.sh  again – your settings and data are kept.
Uninstall:  bash install.sh --uninstall  (your data stays in ~/Library/Application Support/CrossenDrop)
