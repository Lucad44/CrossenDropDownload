#!/usr/bin/env bash
# CrossenDrop installer for macOS (12 Monterey or newer, Apple Silicon or Intel). Installs for your user only –
# no administrator password needed.
#
#   ./install.sh                  # full install (Python environment, CrossenDrop.app, background service)
#   ./install.sh --with-ollama    # also install Ollama (local AI, via Homebrew) and pull the suggested models
#   ./install.sh --no-service     # do not start the background service (it then runs while the app is open)
#   ./install.sh --uninstall      # remove the app (keeps your data in ~/Library/Application Support/CrossenDrop)
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This is the macOS version of CrossenDrop. On Linux, use the Linux version (branch prod-linux)." >&2
  exit 1
fi

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUPPORT="$HOME/Library/Application Support/CrossenDrop"
VENV="$SUPPORT/venv"
APP="$HOME/Applications/CrossenDrop.app"
LABEL="org.example.crossendrop.scheduler"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
LOGS="$HOME/Library/Logs/CrossenDrop"
BIN_DIR="$HOME/.local/bin"
DOMAIN="gui/$(id -u)"
SERVICE=1; OLLAMA=0; UNINSTALL=0

for arg in "$@"; do
  case "$arg" in
    --no-service) SERVICE=0 ;;
    --with-ollama) OLLAMA=1 ;;
    --uninstall) UNINSTALL=1 ;;
    -h|--help) sed -n '2,8p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

say() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWARN:\033[0m %s\n' "$*" >&2; }
have() { command -v "$1" >/dev/null 2>&1; }
stop_service() { launchctl bootout "$DOMAIN/$LABEL" >/dev/null 2>&1 || true; }

if [[ $UNINSTALL -eq 1 ]]; then
  say "Removing CrossenDrop (your data stays in $SUPPORT)"
  stop_service
  rm -f "$AGENT" "$BIN_DIR/crossendrop" "$BIN_DIR/dropforge"
  rm -rf "$APP" "$VENV"
  say "Done."
  exit 0
fi

# ---------------------------------------------------------------- Python 3.12 or newer
# A release download carries the app ready-built, one package per Python version (wheels/): only those Pythons fit.
# A source checkout (the git branch) works with any Python 3.12 or newer.
if [[ -d "$SRC/wheels" ]]; then PY_MAX=14; else PY_MAX=99; fi
py_ok() {
  "$1" -c "import sys; sys.exit(0 if (3, 12) <= sys.version_info[:2] <= (3, $PY_MAX) else 1)" >/dev/null 2>&1
}
find_python() {
  local c
  for c in python3.14 python3.13 python3.12 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
           /Library/Frameworks/Python.framework/Versions/Current/bin/python3 python3; do
    if have "$c" && py_ok "$c"; then command -v "$c"; return 0; fi
  done
  return 1
}
PY="$(find_python || true)"
if [[ -z "$PY" ]]; then
  if have brew; then
    say "Installing Python 3.12 with Homebrew"
    brew install python@3.12
    PY="$(find_python || true)"
  fi
fi
if [[ -z "$PY" ]]; then
  echo "CrossenDrop needs Python 3.12, 3.13 or 3.14. Install it from https://www.python.org/downloads/macos/ (or with" >&2
  echo "Homebrew: brew install python@3.12), then run ./install.sh again." >&2
  exit 1
fi
say "Using $("$PY" -c 'import sys; print("Python " + sys.version.split()[0])') ($PY)"

# ---------------------------------------------------------------- the app's own environment
say "Creating the app's environment in $VENV"
mkdir -p "$SUPPORT"
if [[ -x "$VENV/bin/python" ]] && ! py_ok "$VENV/bin/python"; then rm -rf "$VENV"; fi
"$PY" -m venv "$VENV"
"$VENV/bin/python" -m pip install -q --upgrade pip
# [gui] = the native window (pywebview with macOS's own WebKit)
PKG="$SRC"
if [[ -d "$SRC/wheels" ]]; then
  PYTAG="$("$VENV/bin/python" -c 'import sys; print("cp%d%d" % sys.version_info[:2])')"
  PKG="$(find "$SRC/wheels" -maxdepth 1 -name "crossendrop-*-$PYTAG-none-any.whl" | head -n 1)"
  [[ -n "$PKG" ]] || { echo "This download has no CrossenDrop package for Python $PYTAG; download the newest CrossenDrop." >&2; exit 1; }
fi
"$VENV/bin/python" -m pip install -q "${PKG}[gui]"

if [[ ! -d "$SRC/wheels" && ! -f "$SRC/src/crossendrop/web/static/index.html" ]]; then
  if have npm; then
    say "Building the app window"
    (cd "$SRC/frontend" && npm ci --no-audit --no-fund && npm run build)
    "$VENV/bin/python" -m pip install -q --force-reinstall --no-deps "$SRC"
  else
    warn "The app window's files are missing and npm was not found; download CrossenDrop again."
  fi
fi

say "Linking the crossendrop command into $BIN_DIR"
mkdir -p "$BIN_DIR"
ln -sf "$VENV/bin/crossendrop" "$BIN_DIR/crossendrop"
ln -sf "$VENV/bin/crossendrop" "$BIN_DIR/dropforge"
case ":$PATH:" in
  *":$BIN_DIR:"*) ;;
  *) warn "$BIN_DIR is not on your PATH (only needed for the crossendrop command in Terminal): add" \
          "'export PATH=\"\$HOME/.local/bin:\$PATH\"' to ~/.zprofile." ;;
esac

say "Initialising data folders and database (existing settings and data are kept)"
"$VENV/bin/crossendrop" init --json >/dev/null

# ---------------------------------------------------------------- CrossenDrop.app
say "Installing CrossenDrop.app in ~/Applications"
mkdir -p "$HOME/Applications"
"$VENV/bin/python" -m crossendrop.macos app --app "$APP" --icon "$SRC/packaging/macos/AppIcon.icns" >/dev/null
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
[[ -x "$LSREGISTER" ]] && "$LSREGISTER" -f "$APP" >/dev/null 2>&1 || true

# ---------------------------------------------------------------- background service (launchd)
"$VENV/bin/python" -m crossendrop.macos agent --plist "$AGENT" --logs "$LOGS" >/dev/null
stop_service  # an older version keeps running until it is replaced
if [[ $SERVICE -eq 1 ]]; then
  say "Starting the background service (keeps listings and orders up to date, also when the window is closed)"
  launchctl enable "$DOMAIN/$LABEL" 2>/dev/null || true
  if ! launchctl bootstrap "$DOMAIN" "$AGENT" 2>/dev/null; then
    warn "The background service could not be started now; it starts at your next login."
  fi
else
  warn "--no-service given: the background work runs only while CrossenDrop is open. Start the service later" \
       "with: launchctl bootstrap $DOMAIN \"$AGENT\""
fi

# ---------------------------------------------------------------- optional: local AI
if [[ $OLLAMA -eq 1 ]]; then
  if have ollama || { have brew && say "Installing Ollama with Homebrew" && brew install ollama; }; then
    (have brew && brew services start ollama >/dev/null 2>&1) || (pgrep -x ollama >/dev/null || (ollama serve >/dev/null 2>&1 &))
    sleep 3
    say "Pulling the suggested AI models (this can take a while)"
    read -r TEXT VISION < <("$VENV/bin/python" -c "from crossendrop.ai.hardware import suggest_models as s; m=s(); print(m['text_model'], m['vision_model'])")
    if ! { ollama pull "$TEXT" && ollama pull "$VISION"; }; then
      warn "Model download failed; download them later in Settings → AI."
    fi
  else
    warn "Homebrew not found: install Ollama from https://ollama.com/download, open it once, then choose the models in Settings → AI."
  fi
fi

say "Checking health"
"$VENV/bin/crossendrop" health || true
cat <<MSG

CrossenDrop is installed.
  • Open it from Launchpad or ~/Applications (CrossenDrop), or run:  crossendrop gui
  • The first start walks you through the set-up: your business details, where you sell, your CrossenDrop
    license key (from your purchase e-mail), your eBay seller account and your AliExpress account.
  • Optional – let Claude help with daily operations:  claude mcp add crossendrop -- "$VENV/bin/crossendrop" mcp
MSG
