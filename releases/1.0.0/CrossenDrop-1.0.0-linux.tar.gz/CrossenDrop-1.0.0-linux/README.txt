CrossenDrop 1.0.0 for Linux (Fedora)
==================================

Install
-------
1. Open a terminal in this folder.
2. Run:   bash install.sh
   (add --with-ollama to also install the local AI)

The installer asks for your password once to install system packages, adds CrossenDrop to your app grid and starts
the background service that keeps your listings and orders up to date.

You need Python 3.12, 3.13 or 3.14 (Fedora 40 and newer have it), your CrossenDrop license key, an eBay seller
account and the normal AliExpress account you shop with.

Update:     download the new version and run  bash install.sh  again – your settings and data are kept.
Uninstall:  bash install.sh --uninstall  (your data stays in ~/.local/share/crossendrop/data)
